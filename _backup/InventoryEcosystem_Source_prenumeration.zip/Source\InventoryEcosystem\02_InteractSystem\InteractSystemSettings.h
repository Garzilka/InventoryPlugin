﻿#pragma once
#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "UObject/NoExportTypes.h"
#include "InteractSystemSettings.generated.h"


UCLASS(Config = "Game", defaultconfig, meta = (DisplayName = "Inventory System"))
class INTERACTSYSTEM_API UInteractSystemSettings : public UDeveloperSettings
{
	GENERATED_BODY()
public:
	UPROPERTY(Config, EditAnywhere, Category = "Interact System")
	TSoftObjectPtr<USkeletalMesh> PreviewInteractMesh;

	UPROPERTY(Config, EditAnywhere, Category = "Interact System")
	TSoftObjectPtr<UDataTable> InteractPresets;


	static const UInteractSystemSettings* Get();
};