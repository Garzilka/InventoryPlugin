﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "InteractAnimationComponent.h"

#include "InventoryEcosystem/00_InventoryTools/Library/InventoryToolsLibrary.h"
#include "InventoryEcosystem/02_InteractSystem/InteractSystemSettings.h"
#include "InventoryEcosystem/02_InteractSystem/Object/AnimationInteractRule.h"
#include "Engine/World.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetSystemLibrary.h"

UInteractAnimationComponent::UInteractAnimationComponent()
{
	SetHiddenInGame(true);
	SetIsReplicatedByDefault(true);
	SetIsReplicated(true);
	
	SetCollisionEnabled(ECollisionEnabled::NoCollision);
	SetAnimationMode(EAnimationMode::AnimationSingleNode);
	if (const UInteractSystemSettings* InteractSystemSettings = UInteractSystemSettings::Get())
	{
		if (USkeletalMesh* Mesh = InteractSystemSettings->PreviewInteractMesh.LoadSynchronous())
		{
			SetSkeletalMesh(Mesh);
		}
	}

	AnimationData.bSavedPlaying = false;
	AnimationData.bSavedLooping = false;
	
	if (AnimationRule && AnimationRule->GetPreviewAnimation())
	{
		UAnimationAsset* Montage = Cast<UAnimationAsset>(AnimationRule->GetPreviewAnimation());
		AnimationData.AnimToPlay = TObjectPtr<UAnimationAsset>(Montage);
		AnimationData.SavedPosition = AnimationRule->PreviewTime;
		PlayAnimation(AnimationData.AnimToPlay, false);
		SetPosition(AnimationData.SavedPosition, false);
	}
}

void UInteractAnimationComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	
	DOREPLIFETIME(UInteractAnimationComponent, CurrentInteractor);
}

bool UInteractAnimationComponent::IsClassInstalled()
{
	return (AnimationRule != nullptr);
}

void UInteractAnimationComponent::OnRep_UpdateInteractor()
{
	OnChangeCurrentInteractor.Broadcast(this);
};

void UInteractAnimationComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

#if WITH_EDITOR
	if (GetWorld() && GetPositionType() == EInteractPositionType::EIPT_Radius)
	{
		if ((GetWorld()->WorldType == EWorldType::Editor && !UInventoryToolsLibrary::IsInGameView()) || GetWorld()->WorldType == EWorldType::EditorPreview)
		{
			int32 NumSec = 24;
		
			FRotator Rot = FRotator(0.f, 360, 0.f);		
			UKismetSystemLibrary::DrawDebugConeInDegrees(GetWorld(), GetComponentLocation(), Rot.RotateVector(GetForwardVector()), GetInteractRadius(), 360.f, 0.f, NumSec, FColor::Orange, 0.f, 1.f);
		}
	}
#endif
}

void UInteractAnimationComponent::StartInteraction(APawn* TargetPlayer)
{
	if (!TargetPlayer) return;
	
	if (AnimationRule)
	{
		AnimationRule->StartInteraction(TargetPlayer);
	}
	CurrentInteractor = TargetPlayer;
	OnRep_UpdateInteractor();	
}

void UInteractAnimationComponent::EndInteraction(APawn* TargetPlayer)
{
	if (!TargetPlayer) return;
	
	if (AnimationRule)
	{
		AnimationRule->EndInteraction(TargetPlayer);
	}
}

FTransform UInteractAnimationComponent::GetInteractTransform(bool IsRelative)
{
	if (IsRelative) return GetRelativeTransform();

	FTransform Result;
	FTransform ActorTrnsf = GetOwner()->GetActorTransform();

	FVector LLocation = GetRelativeTransform().GetLocation();
	FRotator LRotation = FRotator(GetRelativeTransform().GetRotation());
	
	Result.SetLocation(UKismetMathLibrary::TransformLocation(ActorTrnsf, LLocation));
	Result.SetRotation(UKismetMathLibrary::TransformRotation(ActorTrnsf, LRotation).Quaternion());

	return Result;
}

void UInteractAnimationComponent::BeginPlay()
{
	Super::BeginPlay();
	SetVisibleFlag(false);
	PrimaryComponentTick.bCanEverTick = false;
	PrimaryComponentTick.bTickEvenWhenPaused = false;
	
	if (AnimationRule)
	{
		AnimationRule->OnInteracted.AddUniqueDynamic(this, &ThisClass::Event_Interacted);
		AnimationRule->OnStartAnimation.AddUniqueDynamic(this, &ThisClass::Event_StartAnimation);
		AnimationRule->OnEndAnimation.AddUniqueDynamic(this, &ThisClass::Event_EndAnimation);
		AnimationRule->OnCancelInteract.AddUniqueDynamic(this, &ThisClass::Event_CancelInteract);
	}
}

#if WITH_EDITOR
void UInteractAnimationComponent::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	SetVisibleFlag(PositionType == EInteractPositionType::EIPT_Point);
	
	Super::PostEditChangeProperty(PropertyChangedEvent);
	
	if (AnimationRule && AnimationRule->GetPreviewAnimation())
	{
		UAnimationAsset* Montage = Cast<UAnimationAsset>(AnimationRule->GetPreviewAnimation());
		AnimationData.AnimToPlay = TObjectPtr<UAnimationAsset>(Montage);
		AnimationData.SavedPosition = AnimationRule->PreviewTime;
		PlayAnimation(AnimationData.AnimToPlay, false);
		SetPosition(AnimationData.SavedPosition, false);
	}
}
#endif

void UInteractAnimationComponent::Event_StartAnimation(APawn* CharacterInstigator,	UAnimationInteractRule* InteractRules)
{
	OnStartAnimation.Broadcast(CharacterInstigator, this, InteractRules);
};

void UInteractAnimationComponent::Event_Interacted(APawn* CharacterInstigator,	UAnimationInteractRule* InteractRules)
{
	OnInteracted.Broadcast(CharacterInstigator, this, InteractRules);
};

void UInteractAnimationComponent::Event_EndAnimation(APawn* CharacterInstigator, UAnimationInteractRule* InteractRules)
{
	OnEndAnimation.Broadcast(CharacterInstigator, this, InteractRules);
};

void UInteractAnimationComponent::Event_CancelInteract(APawn* CharacterInstigator, UAnimationInteractRule* InteractRules)
{
	CurrentInteractor = nullptr;
	OnRep_UpdateInteractor();
};