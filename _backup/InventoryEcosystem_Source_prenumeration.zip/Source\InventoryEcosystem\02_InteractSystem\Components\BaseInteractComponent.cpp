// Fill out your copyright notice in the Description page of Project Settings.


#include "BaseInteractComponent.h"

#include "Components/ArrowComponent.h"
#include "InventoryEcosystem/00_InventoryTools/Library/InventoryToolsLibrary.h"
#include "InventoryEcosystem/02_InteractSystem/InteractSystemSettings.h"

#pragma region ENGINE

UBaseInteractComponent::UBaseInteractComponent()
{
	SetIsReplicatedByDefault(true);
	SetIsReplicated(true);
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = true;
	PrimaryComponentTick.bTickEvenWhenPaused = true;
	bTickInEditor = true;
}

void UBaseInteractComponent::BeginPlay()
{
	Super::BeginPlay();
	SetActive(true);
}

void UBaseInteractComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	
	DOREPLIFETIME(UBaseInteractComponent, Description);
	DOREPLIFETIME(UBaseInteractComponent, InteractSettings);
	DOREPLIFETIME(UBaseInteractComponent, AngleSettings);
	DOREPLIFETIME(UBaseInteractComponent, CurrentInteractors);
	DOREPLIFETIME(UBaseInteractComponent, BlockInteractFor);
}

void UBaseInteractComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

#if WITH_EDITOR
	if (GetWorld() && AngleSettings.bWithAngleCheck && AngleSettings.bEnableDebug)
	{
		if ((GetWorld()->WorldType == EWorldType::Editor && !UInventoryToolsLibrary::IsInGameView()) || GetWorld()->WorldType == EWorldType::EditorPreview)
		{
			int32 NumSec = (int32(AngleSettings.InteractAngle / 10.f) * 2);
		
			FRotator Rot = FRotator(0.f, AngleSettings.InteractAngleOffset, 0.f);
		
			UKismetSystemLibrary::DrawDebugConeInDegrees(GetWorld(), GetComponentLocation(), Rot.RotateVector(GetForwardVector()), InteractSettings.InteractionDistance, (AngleSettings.InteractAngle / 2.0f), 0.f, NumSec, FColor::Blue, 0.f, 0.5f);
			UKismetSystemLibrary::DrawDebugConeInDegrees(GetWorld(), GetComponentLocation(), Rot.RotateVector(GetForwardVector()), InteractSettings.InteractionDistance, 0.f, (AngleSettings.InteractAngle / 2.0f), NumSec, FColor::Blue, 0.f, 0.5f);
			UKismetSystemLibrary::DrawDebugConeInDegrees(GetWorld(), GetComponentLocation(), Rot.RotateVector(GetForwardVector()), InteractSettings.InteractionDistance, (AngleSettings.InteractAngle / 2.0f), (AngleSettings.InteractAngle / 2.0f), NumSec, FColor::Blue, 0.f, 0.5f);
		}
	}
#endif
	
	if (!InInteract)
	{
		if (InteractSettings.TypeTimeDegradation == EInteractTypeTimeDegradation::EITTD_Reverse && CurrentInteractTime > 0.001f)
			CurrentInteractTime -= (DeltaTime * InteractSettings.SpeedOfRevers);
		return;
	}
	
	CurrentInteractTime = (CurrentInteractTime > InteractSettings.InteractionTime ? InteractSettings.InteractionTime : CurrentInteractTime + DeltaTime);
}

#pragma endregion ENGINE

bool UBaseInteractComponent::SetInteractNameText(FText NewNameText)
{
	if (!HasAuthority()) return false;
	
	Description.NameText = NewNameText;
	return true;
}

bool UBaseInteractComponent::SetInteractActionText(FText NewActionText)
{
	if (!HasAuthority()) return false;
	
	Description.ActionText = NewActionText;
	return true;
}

void UBaseInteractComponent::SetInteractPresset(FName InteractPresset)
{
	//if (!(HasAuthority() || !HasBegunPlay())) return;
	const UInteractSystemSettings* InteractSystemSettings = UInteractSystemSettings::Get();
	if (!InteractSystemSettings) return;

	auto DataTable = InteractSystemSettings->InteractPresets.LoadSynchronous();
	if (!DataTable) return;

	FInteractPresset* Presset = DataTable->FindRow<FInteractPresset>(InteractPresset, "");
	if (!Presset) return;
	
	Description = Presset->Description;
	InteractSettings = Presset->InteractSettings;
	AngleSettings = Presset->AngleSettings;
}

void UBaseInteractComponent::BeginFocus(APawn* CharacterInstigator)
{
	OnBeginFocus.Broadcast(CharacterInstigator, this, GetOwner());

	ActivateOutLine();
}

void UBaseInteractComponent::EndFocus(APawn* CharacterInstigator)
{
	OnBeginFocus.Broadcast(CharacterInstigator, this, GetOwner());

	DeactivateOutLine();
}

void UBaseInteractComponent::Interact(APawn* CharacterInstigator, EInteractType InteractType)
{
	if (!CanInteractFor(CharacterInstigator)) return;

	CurrentInteractTime = 0.f;

	if (InteractType != EInteractType::EIT_CirculPressed)
		InInteract = false;

	OnInteracted.Broadcast(CharacterInstigator, this, InteractType);
}

void UBaseInteractComponent::StartInteract(APawn* CharacterInstigator)
{
	if (!CanInteractFor(CharacterInstigator)) return;
	InInteract = CanBePressed();
	OnBeginInteract.Broadcast(CharacterInstigator, this);
}

void UBaseInteractComponent::EndInteract(APawn* CharacterInstigator)
{
	InInteract = false;
	CurrentInteractTime = (InteractSettings.TypeTimeDegradation == EInteractTypeTimeDegradation::EITTD_Clear ? 0.f : CurrentInteractTime);
	OnEndInteract.Broadcast(CharacterInstigator, this);
}

bool UBaseInteractComponent::IsOutLine(UPrimitiveComponent* Primitive)
{
	if (!IsValid(Primitive)) return false;
	return Primitive->ComponentTags.Contains("OutLine");
}

float UBaseInteractComponent::GetTimeToInteract() const
{
	return (InteractSettings.InteractionTime - CurrentInteractTime < 0 ? 0.f : InteractSettings.InteractionTime - CurrentInteractTime);
}

float UBaseInteractComponent::GetInteractPercent() const
{
	if (InteractSettings.InteractionTime > 0)
	{
		return (CurrentInteractTime / InteractSettings.InteractionTime);
	}
	
	return 0.f;
}

void UBaseInteractComponent::ActivateOutLine()
{
	if (IsNetMode(ENetMode::NM_DedicatedServer)) return;
	
	TArray<UPrimitiveComponent*> Primitives;
	GetOwner()->GetComponents<UPrimitiveComponent>(Primitives);
	for (auto VisualComp : Primitives)
	{
		if (IsOutLine(VisualComp))
			VisualComp->SetRenderCustomDepth(true);
	}
}

void UBaseInteractComponent::DeactivateOutLine()
{
	if (IsNetMode(ENetMode::NM_DedicatedServer)) return;
	
	TArray<UPrimitiveComponent*> Primitives;
	GetOwner()->GetComponents<UPrimitiveComponent>(Primitives);
	for (auto VisualComp : Primitives)
	{
		if (IsOutLine(VisualComp))
			VisualComp->SetRenderCustomDepth(false);
	}
}

bool UBaseInteractComponent::CanInteractFor(APawn* CharacterInstigator) const
{
	if (!IsActive()) return false;
	if (InteractSettings.bIsOnlyOneInteractor && CurrentInteractors.Num() > 0 && !CurrentInteractors.Contains(CharacterInstigator)) return false;

	return (BlockInteractFor.Find(FBlockInteractInfo(CharacterInstigator)) == INDEX_NONE);
}

bool UBaseInteractComponent::CanViewFor(APawn* CharacterInstigator) const
{
	if (!IsActive())	return false;

	int32 Idx = BlockInteractFor.Find(FBlockInteractInfo(CharacterInstigator));
	if (Idx == INDEX_NONE) return true;

	return BlockInteractFor[Idx].CanViewInteractWidget;
}

bool UBaseInteractComponent::HasInteractFlag(EInteractType Type) const
{
	return (((uint8)InteractSettings.ActionMenu) & ((uint8)Type));
}

bool UBaseInteractComponent::CanBePressed() const
{
	return (HasInteractFlag(EInteractType::EIT_Pressed) || HasInteractFlag(EInteractType::EIT_Released) || HasInteractFlag(EInteractType::EIT_CirculPressed));
}
