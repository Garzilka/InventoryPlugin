﻿#pragma once
#include "InventoryEcosystemEditor/06LootSystemEditor/LootDataEditor/LootEditorAssetEditor.h"
#include "InventoryEcosystemEditor/06LootSystemEditor/LootDataEditor/LootEditorWidgets/Controll/W_ArrayController.h"

class SW_AC_LootPreset: public SW_ArrayController
{
public:
	virtual TSharedRef<SW_BaseArrayElement> CreateArrayElement(TSharedPtr<IPropertyHandle> InPropertyHandle_Array, int32 Idx, TWeakPtr<FLootEditorAssetEditor> InLootAssetEditor) override;
};


class SW_LootPreset : public SCompoundWidget
{
public:
	
	SLATE_BEGIN_ARGS(SW_LootPreset)
		: _PropertyHandle_Struct(nullptr),
		 _LootAssetEditorRef(TWeakPtr<FLootEditorAssetEditor>())
	{}
	SLATE_ARGUMENT(TSharedPtr<IPropertyHandle>, PropertyHandle_Struct)
	SLATE_ARGUMENT(TWeakPtr<FLootEditorAssetEditor>, LootAssetEditorRef)
		
SLATE_END_ARGS();
	void Construct(const FArguments& InArgs);
	EVisibility OnGetRespawnDataVisibility() const;
protected:
	TSharedPtr<SVerticalBox> VB_Array;
	TSharedPtr<SExpandableArea> CategoryExpand;
	
	TWeakPtr<FLootEditorAssetEditor> LootAssetEditor;
	TSharedPtr<IPropertyHandle> PropertyHandle_Struct;
	TSharedPtr<IPropertyHandle> PropertyHandle_bUseRespawnView;
	TSharedPtr<IPropertyHandle> PropertyHandle_bIsUniqueLoot;
	TSharedPtr<IPropertyHandle> PropertyHandle_RespawnSettings;
	TSharedPtr<IPropertyHandle> PropertyHandle_GenerateBlocks;
};
