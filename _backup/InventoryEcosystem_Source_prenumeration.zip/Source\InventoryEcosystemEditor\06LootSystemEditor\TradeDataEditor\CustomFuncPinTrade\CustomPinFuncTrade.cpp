﻿#include "CustomPinFuncTrade.h"
