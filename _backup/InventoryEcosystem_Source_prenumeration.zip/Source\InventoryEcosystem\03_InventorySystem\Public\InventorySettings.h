// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "InventorySettings.generated.h"

UCLASS(Config = "Game", defaultconfig, meta = (DisplayName = "Inventory System"))
class INVENTORYSYSTEM_API UInventorySettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UPROPERTY(Config, EditAnywhere, Category = "Inventory System")
	float ItemCellSize = 50.f;
	
	UPROPERTY(Config, EditAnywhere, Category = "Inventory System")
	FName InteractProfile = FName("Interacted");
};